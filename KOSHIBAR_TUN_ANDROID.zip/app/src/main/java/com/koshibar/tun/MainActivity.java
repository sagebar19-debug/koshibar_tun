package com.koshibar.tun;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xff050505);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "KoshibarNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private class Bridge {
        @JavascriptInterface public void connect(String config) {
            runOnUiThread(() -> {
                Toast.makeText(MainActivity.this,
                    "Moteur SSH/Xray non intégré : VPN non connecté", Toast.LENGTH_LONG).show();
                web.evaluateJavascript("window.koshibarVPNStatus && window.koshibarVPNStatus('disconnected')", null);
            });
        }
        @JavascriptInterface public void disconnect() {
            runOnUiThread(() -> web.evaluateJavascript(
                "window.koshibarVPNStatus && window.koshibarVPNStatus('disconnected')", null));
        }
    }
    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }
}
