# KOSHIBAR TUN — Projet Android (version de base)

Cette version **compile l'interface HTML en APK Android** et affiche les deux ninjas animés. **Ce n'est PAS encore un VPN fonctionnel** : le moteur natif SSH/Xray, le routage et Android VpnService restent à développer/intégrer. Le bouton ninja ne simule pas de connexion réussie.

## Depuis un téléphone
1. Décompresser l'archive, puis déposer son contenu **à la racine** du dépôt GitHub `KOSHIBAR-TUN` (ne pas déposer uniquement le ZIP).
2. Vérifier que `.github/workflows/android.yml`, `app/build.gradle`, `app/src/main/assets/index.html` existent dans le dépôt.
3. Dans GitHub : **Actions** → **Compiler APK Android** → **Run workflow** (ou pousser sur `main`).
4. Attendre la fin du workflow, ouvrir son exécution et télécharger l'artifact **KOSHIBAR-TUN-APK**.
5. Décompresser l'artifact, puis installer `app-debug.apk` sur Android (autoriser l'installation depuis la source utilisée, si demandé).

Le build `debug` sert uniquement aux essais. Ne pas publier comme application VPN fonctionnelle.

## Étape technique suivante
Implémenter un vrai service Android `VpnService`, obtenir le consentement via `VpnService.prepare()`, établir une interface TUN, intégrer un moteur de transfert réseau compatible avec Xray et un moteur SSH adapté, gérer le cycle de vie et les erreurs, puis ne signaler `connected` au JavaScript qu'après confirmation réelle. Une simple permission VPN ou un WebView ne suffisent pas.

Ne pas saisir de véritables mots de passe SSH dans cette version : le HTML conserve les paramètres localement sans coffre chiffré.
